﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jump_around : MonoBehaviour {

    float time_cnt;
    float speed;
    Vector3 pos;

	// Use this for initialization
	void Start () {
        time_cnt = 0.0f;
        speed = 5.0f;
	}
	
	// Update is called once per frame
	void Update () {
        time_cnt = time_cnt + Time.deltaTime;

        pos.x = Mathf.Sin(Time.time * speed) * 2.0f;
        pos.y = 0.8f+ Mathf.Abs(Mathf.Sin(Time.time * speed *4));
        pos.z = Mathf.Cos(Time.time * speed) * 2.0f;

        Transform myTransform = this.transform;
        myTransform.position = pos;

    }
}
