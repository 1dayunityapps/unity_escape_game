﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Input_Manager : MonoBehaviour {

    public InputField inputField;
    public GameObject Text;

    public Text input_Text;
    public Text save_1_text;
    public Text save_2_text;
    public Text save_3_text;

    // Use this for initialization
    void Start () {

        /// InputFieldコンポーネントの取得および初期化メソッドの実行
        inputField = GameObject.Find("InputField").GetComponent<InputField>();
        InitInputField();

        save_1_text = GameObject.Find("Save_1_text").GetComponent<Text>();
        save_2_text = GameObject.Find("Save_2_text").GetComponent<Text>();
        save_3_text = GameObject.Find("Save_3_text").GetComponent<Text>();

        if(PlayerPrefs.HasKey("save_1")) {
            save_1_text.text = PlayerPrefs.GetString("save_1");
        }
        if (PlayerPrefs.HasKey("save_2"))
        {
            save_2_text.text = PlayerPrefs.GetString("save_2");
        }
        if (PlayerPrefs.HasKey("save_3"))
        {
            save_3_text.text = PlayerPrefs.GetString("save_3");
        }
    }

    // Update is called once per frame
    void Update () {
	}


    public void Save_1_clicked(){
        save_1_text.text = inputField.text;
        PlayerPrefs.SetString("save_1", save_1_text.text);
    }
    public void Save_2_clicked()
    {
        save_2_text.text = inputField.text;
        PlayerPrefs.SetString("save_2", save_2_text.text);
    }
    public void Save_3_clicked()
    {
        save_3_text.text = inputField.text;
        PlayerPrefs.SetString("save_3", save_3_text.text);
    }

    public void Delete_1_clicked()
    {
        save_1_text.text = "";
        PlayerPrefs.DeleteKey("save_1");
    }

    public void Delete_2_clicked()
    {
        save_2_text.text = "";
        PlayerPrefs.DeleteKey("save_2");
    }

    public void Delete_3_clicked()
    {
        save_3_text.text = "";
        PlayerPrefs.DeleteKey("save_3");
    }

    public void Delete_ALL_clicked()
    {
        save_1_text.text = "";
        save_2_text.text = "";
        save_3_text.text = "";
        PlayerPrefs.DeleteAll();
    }

    void InitInputField()
    {
        // 値をリセット
        inputField.text = "";
        // フォーカス
        inputField.ActivateInputField();
    }
}
