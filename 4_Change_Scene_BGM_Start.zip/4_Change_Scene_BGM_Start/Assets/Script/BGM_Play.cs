﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGM_Play : MonoBehaviour {

    public AudioSource sound01;
    public AudioClip bgm;


    // Use this for initialization
    void Start () {
        sound01 = GameObject.Find("Audio Source").GetComponent<AudioSource>();
        sound01.clip = bgm;
        }
	
	// Update is called once per frame
	void Update () {
            }

    public void OnBGMClicked(){
        sound01.Play();
//      sound01.PlayOneShot(bgm);
        Debug.Log("played");
    }

}
