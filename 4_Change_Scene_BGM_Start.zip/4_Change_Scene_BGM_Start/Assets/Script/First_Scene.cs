﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class First_Scene : MonoBehaviour {

    public static int title_load_flg = 0;

    public static int getLoadFlg()
    {
        return title_load_flg;
    }

    // Use this for initialization
    void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	}

    public void OnChangeScene_1_ButtonClicked()
    {
        SceneManager.LoadScene("NextScene");
        title_load_flg = 1;
    }

    public void OnChangeScene_2_ButtonClicked()
    {
        SceneManager.LoadScene("NextScene");
        title_load_flg = 2;
    }


}
