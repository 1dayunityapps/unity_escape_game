﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Text_Write : MonoBehaviour {


    public Text targetText;

	// Use this for initialization
	void Start () {
            this.targetText = this.GetComponent<Text>(); // <---- 追加3
        this.targetText.text = "ChangeText" + First_Scene.getLoadFlg(); // <---- 追加4

    }

    // Update is called once per frame
    void Update () {
		
	}
}
