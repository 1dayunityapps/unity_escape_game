﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button_Controller : MonoBehaviour {

    public GameObject Cube;

	// Use this for initialization
	void Start () {
        Cube = GameObject.Find("Cube");
	}
	
	// Update is called once per frame
	void Update () {
	}

    public void UpOnClick()
    {
        Debug.Log("UP Button click!");
        Cube.transform.position += new Vector3(0, 0, 1);
    }

    public void DownOnClick()
    {
        Debug.Log("DOWN Button click!");
        Cube.transform.position += new Vector3(0, 0, -1);
    }
    public void LeftOnClick()
    {
        Debug.Log("LEFT Button click!");
        Cube.transform.position += new Vector3(-1, 0, 0);
    }
    public void RightOnClick()
    {
        Debug.Log("RIGHT Button click!");
        Cube.transform.position += new Vector3(1, 0, 0);
    }

    public void CenterOnClick()
    {
        Debug.Log("CENTER Button click!");
        Cube.transform.position = new Vector3(0, 5, 0);
    }

    public void JumpOnClick()
    {
        Debug.Log("JUMP Button click!");
        Rigidbody rb  = Cube.gameObject.GetComponent<Rigidbody>();
        rb.AddForce(new Vector3(0, 500, 0));
    }


}
