﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Object_Tap : MonoBehaviour
{
    public GameObject mainCamera; //カメラの定義

    //タッチイベント用変数
    public EventSystem eventsystem; //イベントシステム（いろんなことに使う）の定義
    public Ray ray;
    public Ray rayItem;
    public RaycastHit hit;
    public GameObject selectedGameObject;


    public GameObject Cube_2;
    public GameObject Cube_3_face;

    //Cube_2のテクスチャ変数
    public Texture2D TEX_MarbleFloor;
    public Texture2D TEX_PlaidBlueFloor;
    public Texture2D TEX_PlaidBrownCrackedFloor;

    //Cube_3のテクスチャ変数
    public Texture2D[] TEX_Cube3;
    public int cnt_tex_cube3;

    // Use this for initialization
    void Start()
    {
        Cube_2 = GameObject.Find("Cube_2");
        Cube_3_face = GameObject.Find("Cube_3_face");

        eventsystem = GameObject.Find("EventSystem").GetComponent<EventSystem>();

        TEX_MarbleFloor = Resources.Load<Texture2D>("Texture/MarbleFloor");
        TEX_PlaidBlueFloor = Resources.Load<Texture2D>("Texture/PlaidBlueFloor");
        TEX_PlaidBrownCrackedFloor = Resources.Load<Texture2D>("Texture/PlaidBrownCrackedFloor");
        Cube_2.GetComponent<Renderer>().material.mainTexture = TEX_PlaidBrownCrackedFloor;

        TEX_Cube3 = new Texture2D[10];
        cnt_tex_cube3 = 0;

        for (int i = 0;i < TEX_Cube3.Length; i++){
            Debug.Log("Texture/" + i);
            TEX_Cube3[i] = Resources.Load<Texture2D>("Texture/" + i);
        }

        Cube_3_face.GetComponent<Renderer>().material.mainTexture = TEX_Cube3[0];

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        { //左クリック
            if (eventsystem.currentSelectedGameObject == null)
            {// UI以外（3D）をさわった
                searchRoom(); //3Dオブジェクトをクリックした時の処理
                if(selectedGameObject==null){}
                else{
                    switch (selectedGameObject.name)
                    {
                        //クリックしたものがCube_2
                        case "Cube_2":
                            Debug.Log("clicked");
                        if(Cube_2.GetComponent<Renderer>().material.mainTexture == TEX_PlaidBrownCrackedFloor){
                            Cube_2.GetComponent<Renderer>().material.mainTexture = TEX_MarbleFloor;
                        }
                        else if (Cube_2.GetComponent<Renderer>().material.mainTexture == TEX_MarbleFloor)
                        {
                            Cube_2.GetComponent<Renderer>().material.mainTexture = TEX_PlaidBlueFloor;
                        }
                        else if (Cube_2.GetComponent<Renderer>().material.mainTexture == TEX_PlaidBlueFloor)
                        {
                            Cube_2.GetComponent<Renderer>().material.mainTexture = TEX_PlaidBrownCrackedFloor;
                        }
                        break;

                        case "Cube_3_face":
                            if(cnt_tex_cube3 == 9){
                                Cube_3_face.GetComponent<Renderer>().material.mainTexture = TEX_Cube3[0];
                                cnt_tex_cube3 = 0;
                            }else{
                                Cube_3_face.GetComponent<Renderer>().material.mainTexture = TEX_Cube3[cnt_tex_cube3+1];
                                cnt_tex_cube3++;
                            }
                            break;
                    }
                }
            }
            else { }
        }
    }

 public void searchRoom(){
        selectedGameObject = null;
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit, 10000000, 1 << 9))
        {
            selectedGameObject = hit.collider.gameObject;
            Debug.Log(selectedGameObject.name + " << 3D_clicked_as_objtap");
        }
    }
}


